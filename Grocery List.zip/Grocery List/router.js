var grocery_operations = require('./controllers/grocery_list_operations');

module.exports = function(app){
    app.post('/init_app',grocery_operations.init_app);
    app.get('/fetch_grocery_list/:item_id',grocery_operations.fetch_grocery_items);
    app.post('/add_new_grocery_item',grocery_operations.add_new_grocery_item); 
    app.put('/complete_item/:item_id/:checkbox_val',grocery_operations.complete_item);
    app.delete('/delete_item/:item_id',grocery_operations.delete_item);
}