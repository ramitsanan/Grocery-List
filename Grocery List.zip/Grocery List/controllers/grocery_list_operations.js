const db_handler = require('../services/database.js');

exports.init_app = function(req,res,next){
    var create_db = "CREATE DATABASE IF NOT EXISTS grocery_list_db";
    db_handler.query(create_db)
    .then(function(db_res){
        var create_db_tables = " CREATE TABLE IF NOT EXISTS `grocery_list_db`.`grocery_items` (" + 
                                                        " `item_id` int(11) NOT NULL AUTO_INCREMENT, " + 
                                                        " `item_title` varchar(60) DEFAULT NULL, " + 
                                                        " `item_description` varchar(200) DEFAULT NULL, " + 
                                                        " `item_status` enum('0','1') DEFAULT '1', " + 
                                                        " `item_completed` enum('false','true') DEFAULT 'false', " +
                                                        " PRIMARY KEY (`item_id`))  ENGINE=InnoDB DEFAULT CHARSET=utf8" ;
        db_handler.query(create_db_tables)
        .then(function(db_table_res){
            res.status(200).json({
                success: 'true'
            }) 
        })                                                
        .catch(function(db_table_err){
            console.log(db_table_err);
            res.status(200).json({
                success: 'false',
                error : db_table_err
            }); 
        })
    })
    .catch(function(db_err){
        console.log(db_err);
        res.status(200).json({
            success: 'false',
            error: db_err
        }); 
    });
}

exports.fetch_grocery_items = function(req,res,next){
    // All items
    var where_clause = ' WHERE item_completed = "false"';
    // Individual item.
    if(Object.keys(req.params).length && req.params.item_id != 'all' && req.params.item_id != 'completed'){
        where_clause = " WHERE item_id = " + req.params.item_id + " AND item_completed = 'false'";
    }
    // Completed Items
    if(Object.keys(req.params).length && req.params.item_id == 'completed'){
        where_clause = " WHERE item_completed = 'true'";
    }
    var fetch_stm = "SELECT item_id,item_title,item_description,item_status,item_completed " + 
                    "  FROM grocery_list_db.grocery_items " + 
                    where_clause;
    console.log(fetch_stm)                
    db_handler.query(fetch_stm)
    .then(function(fetch_stm_res){
        console.log('Fetching all items');
        res.status(200).json({
            success: 'true',
            data: fetch_stm_res
        });
    })  
    .catch(function(fetch_stm_err){
        console.log(fetch_stm_err);
        res.status(200).json({
            success: 'false',
            error: fetch_stm_err
        }); 
    })              
}

exports.add_new_grocery_item = function(req,res,next){
     // make sure grocery item title is a mandatory field
    if(req.body.model.item_title != ''){
        var item_id_value = req.body.model.item_id;
        if(req.body.model.form_type == 'new'){
            item_id_value = "NULL";
        }
        var insert_stm = " INSERT INTO grocery_list_db.grocery_items " + 
                                    " VALUES (" + item_id_value + "," + db_handler.escape(req.body.model.item_title) + "," + db_handler.escape(req.body.model.item_description) + ",'1','false') " + 
                                    " ON DUPLICATE KEY UPDATE item_id = VALUES (item_id), item_title = VALUES (item_title), item_description = VALUES(item_description)";
        db_handler.query(insert_stm)
        .then(function(insert_stm_res){
            console.log('Inserting item');
            res.status(200).json({
                success: 'true',
                data: insert_stm_res
            });
        })  
        .catch(function(insert_stm_err){
            console.log(insert_stm_err);
            res.status(200).json({
                success: 'false',
                error: insert_stm_err
            }); 
        })
    }
    else {
        res.status(200).json({
            success: 'false',
            data: "Please enter an item title"
        });
    }           
}

exports.complete_item = function(req,res,next){
    console.log(req.params)
    var checkbox_val = 'false';
    if(req.params.checkbox_val == '1'){
       checkbox_val = 'true';
    }
    var update_stm  = "UPDATE grocery_list_db.grocery_items" + 
                        " SET item_completed = '" + checkbox_val + "' " +  
                       " WHERE item_id = " + req.params.item_id;
    console.log(update_stm)                   
    db_handler.query(update_stm)
    .then(function(update_stm_res){
        res.status(200).json({
            success: 'true',
            data: update_stm_res
        });
    })
    .catch(function(upd_err){
        res.status(200).json({
            success: 'false',
            error: upd_err
        });
    })   
}

exports.delete_item = function(req,res,next){
    var delete_stm  = "DELETE FROM grocery_list_db.grocery_items" +   
                       " WHERE item_id = " + req.params.item_id;
    console.log(delete_stm)                   
    db_handler.query(delete_stm)
    .then(function(delete_stm_res){
        res.status(200).json({
            success: 'true',
            data: delete_stm_res
        });
    })
    .catch(function(delete_stm_err){
        res.status(200).json({
            success: 'false',
            error: delete_stm_err
        });
    })   
}

