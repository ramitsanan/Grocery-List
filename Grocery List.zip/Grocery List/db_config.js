/**
 * This file stores mysql credentials, will need to change to be used on a different platform
 */
module.exports = { 
    credentials : {
        host : 'localhost',
        user: 'root',
        port: 3306,
        password: 'user',
        database : 'test' 
    }
}