const express = require('express');
const mysql = require('mysql');
const router = require('./router');
const config = require('./db_config.js');
var bodyParser = require('body-parser')
const db = mysql.createConnection(config.credentials);

db.connect((err) => {
    if(err){
        console.log(err);
    }
    else {
        console.log('mysql connected')
    }
})


const app = express();

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

app.use(express.static(__dirname + "/src"));
router(app);
app.listen(3000,() => {
    console.log('listening on 3000')
})