var grocery_app = angular.module('grocery_list',['ngRoute','ngTable','ui.bootstrap','cgBusy']);


grocery_app.config(function($routeProvider){
    
    $routeProvider.when('/',{
        templateUrl: 'templates/view_list.html',
        controller: 'view_list_controller'
    })
});

grocery_app.controller('view_list_controller',['$rootScope','$http','$scope','NgTableParams','$uibModal',function($rootScope,$http,$scope,NgTableParams,$uibModal){
    // Create DB if does not exist
    var count = 0;
    
    function init_fetch(){
        count++;
        $scope.myPromise = $http.post('/init_app',{})
        .then(function(response){
            if(response.data.success){
                if(count == 1){
                    alert("DB and tables have been successfully created.");
                }
                // fetch all
                $scope.myPromise = $http.get('/fetch_grocery_list/all')
                .then(function(grocery_response){
                    $scope.grocery_items = grocery_response.data.data;
                    $scope.tableParams = new NgTableParams(
                        {
                            count:5
                        },
                        {
                            dataset : $scope.grocery_items,
                            counts: []
                        }
                    );
                })
                .catch(function(grocery_fetch_err){
                    alert("There was an error: " + grocery_fetch_err);
                    return false;
                })
            }
            else {
                alert("Error encountered: " + response.data.error);
                return false;
            }
        })
        .catch(function(err){
            alert("Error encountered: " + err);
            return false;
        })
    }
    
    $rootScope.$on('call_init_func',function(){
        init_fetch();
    });

    $rootScope.$emit('call_init_func');

    // Create new item
    $scope.add_item =  function(type,id){
        var uibmodal = $uibModal.open({
            animation: 'true',
            templateUrl: 'add_new_list_item.html',
            controller: 'add_new_list_item_ctrl',
            size:'lg',
            resolve: {
                parameters: {
                    form_type: type,
                    item_id : id
                }
            }
        });
        uibmodal.result.then(function(){
        },function(response){
            $rootScope.$emit('call_init_func');
        });
    }
    
    // Complete Item
    $scope.complete_item = function(items){
        var new_checkbox_val = 0;
        console.log(items.checkbox_value)
        if(items.checkbox_value){
            new_checkbox_val = 1;
        }
        // console.log(new_checkbox_val)
        $scope.myPromise = $http.put('/complete_item/'+items.item_id+'/'+new_checkbox_val)
        .then(function(response){
            alert('Item: ' + items.item_title + ' has been marked complete.');
            $rootScope.$emit('call_init_func');
        })
        .catch(function(err){
            alert('Encountered an error. Check console');
            return false;
            console.log(err);
        })
    }

    // View All Completed Items
    $scope.view_completed_items = function(){
        var uibmodal = $uibModal.open({
            animation: 'true',
            templateUrl: 'view_completed_items.html',
            controller: 'view_completed_items_ctrl',
            size:'lg',
        });
        uibmodal.result.then(function(){
        },function(response){
            $rootScope.$emit('call_init_func');
        });
    }   
    
    // Delete Item
    $scope.delete_item = function(items){
        $scope.myPromise = $http.delete('/delete_item/'+items.item_id)
        .then(function(response){
            alert('Item: ' + items.item_title + ' has been deleted successfully.');
            $rootScope.$emit('call_init_func');
        })
        .catch(function(err){
            alert('Encountered an error. Check console');
            return false;
            console.log(err);
        })
    }

}]);

grocery_app.controller('add_new_list_item_ctrl',['parameters','$http','$scope','NgTableParams','$uibModalInstance',function(parameters,$http,$scope,NgTableParams,$uibModalInstance){
    $scope.list_item = {};
    $scope.dynamic_form_btn = "Submit";
    $scope.dynamic_form_title = "Add a grocery item!"

    if(parameters.form_type == 'view')
    {
        $scope.dynamic_form_btn = "Update";
        $scope.dynamic_form_title = "Update a grocery item!"
        $scope.myPromise = $http.get('/fetch_grocery_list/'+parameters.item_id)
        .then(function(response){
            $scope.list_item = {
                item_title: response.data.data[0].item_title,
                item_description: response.data.data[0].item_description
            }
        })
        .catch(function(err){
            alert('Encountered an error. Check console');
            return false;
            console.log(err);
        })
    }
    // This controller adds a new grocery list item. 
    $scope.add_new_grocery_item = function(form_data){
        form_data.form_type = parameters.form_type;
        form_data.item_id = parameters.item_id;
        // make sure grocery item title is a mandatory field
        if(form_data.item_title && (form_data.item_title != '' && form_data.item_title != null && form_data.item_title != undefined))
        {   
            $scope.myPromise = $http.post('/add_new_grocery_item',{model:form_data}) 
            .then(function(response){
                if(response.data.success){
                    alert(form_data.item_title + " has been successfully added into the system.");
                    $uibModalInstance.dismiss('cancel');
                }
                else {
                    alert('There was an error in the insertion process. Error message: ' + response.data.error);
                    return false;
                }
            }) 
        }
        else {
            alert('Please enter an item title in order to proceed.');
            return false;
        } 
    }

    $scope.close_new_item_modal = function(){
        $uibModalInstance.dismiss('cancel');
    }
}]);

grocery_app.controller('view_completed_items_ctrl',['$http','$scope','NgTableParams','$uibModalInstance','$rootScope',function($http,$scope,NgTableParams,$uibModalInstance,$rootScope){
    
    $scope.myPromise =  $http.get('/fetch_grocery_list/completed')
    .then(function(response){
        $scope.results = response.data.data;
        $scope.tableParams = new NgTableParams(
            {
                count:5
            },
            {
                dataset :  $scope.results,
                counts: []
            }
        );
    })
    .catch(function(err){
        alert("Error encountered");
        return false;
    })

    $scope.unpurchase_item = function(items){
        $scope.myPromise = $http.put('/complete_item/'+items.item_id+'/0')
        .then(function(response){
            if(response.data.success){
                alert('Item: ' + items.item_title + ' has been marked un-complete.');
                $uibModalInstance.dismiss('cancel');
                $rootScope.$emit('call_init_func');
            }
        })
        .catch(function(err){
            alert("Error encountered");
            return false;
            console.log(err);
        })
    }

    $scope.close_new_item_modal = function(){
        $uibModalInstance.dismiss('cancel');
    }
}]);
