const mysql = require('mysql');
const config = require('../db_config.js');


exports.query = function(sql_query){
    return new Promise((resolve, reject) => {
        var connection = mysql.createConnection(config.credentials);
        connection.connect(function(err){
            if(!err) {
                connection.query(sql_query, function(err, rows) {
                    if(err) {
                        connection.end();
                        reject(err);
                    } else {
                        connection.end();
                        resolve(rows);
                    }
                });
            } 
            else {
                connection.end();
                reject(err);
            }
 
        });
    });
};
 exports.escape = function(variable){
     var connection = mysql.createConnection(config.credentials);
     var escaped_var = connection.escape(variable);
     connection.end();
     console.log(escaped_var);
     return escaped_var ;
 }